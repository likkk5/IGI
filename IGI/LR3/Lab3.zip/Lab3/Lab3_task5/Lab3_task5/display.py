def display_list(lst):
    """
    Function to display the list on the screen
    Args:
    lst (list): List of real numbers
    """
    print("List of numbers:", lst)

