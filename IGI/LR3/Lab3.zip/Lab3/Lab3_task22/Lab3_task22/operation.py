
def perform_operation(a, count):

 """
    Function to count numbers greater than 12 in the sequence
    Args:
    sequence (list): Input sequence
    Returns:
    int: Count of numbers greater than 12
    """
  
 if a>12 :
  count+=1
 return count